import { Route, Routes } from 'react-router-dom';
import React from 'react';
import Login from '../src/screen/Login';
import Registration from '../src/screen/Registration';
import PrivateRoute from './utils/PrivateRoute';
import UserDashboard from './screen/User/UserDashboard';
import SubmitPoc from './screen/User/SubmitPoc';
import PocStatus from './screen/User/PocStatus';
import RenewPoc from './screen/User/RenewPoc';
import DownloadSolution from './screen/User/DownloadSolution';

const registrationToken = localStorage.getItem('registrationToken');
const loginToken = localStorage.getItem('loginToken');

const isAuthenticated = registrationToken || loginToken;

const ApplicationRoutes = () => {
    if (true) {
        return (
            <Routes>
                <Route exact path="/" element={<Login />} />
                <Route exact path="/registration" element={<Registration />} />
                <Route exact path="/dashboard" element={<PrivateRoute isAuthenticated={isAuthenticated} component={UserDashboard} />} />
                <Route exact path="/dashboard/submit-poc" element={<PrivateRoute isAuthenticated={isAuthenticated} component={SubmitPoc} />} />
                <Route exact path="/dashboard/poc-status" element={<PrivateRoute isAuthenticated={isAuthenticated} component={PocStatus} />} />
                <Route exact path="/dashboard/renew-poc" element={<PrivateRoute isAuthenticated={isAuthenticated} component={RenewPoc} />} />
                <Route exact path="/dashboard/download-solution" element={<PrivateRoute isAuthenticated={isAuthenticated} component={DownloadSolution} />} />
            </Routes>
        )
    } else {
        return (
            <></>
        )
    }
}

export default ApplicationRoutes