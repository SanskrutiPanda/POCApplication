import { EDIT_USER_REQUEST, EDIT_USER_SUCCESS, EDIT_USER_FAILURE } from "../actions/Action";

const initialState = {
    edited:false,
    loading: false,
    user: {},
    error: ''
  };
  
  const editUserReducer = (state = initialState, action) => {
    switch (action.type) {
      case EDIT_USER_REQUEST:
        return {
          ...state,
          loading: true,
          edited:false,
        };
      case EDIT_USER_SUCCESS:
        return {
          loading: false,
          user: action.payload,
          error: '',
          edited:true,
        };
      case EDIT_USER_FAILURE:
        return {
          loading: false,
          user: {},
          error: action.payload,
          edited:false,
        };
      default:
        return state;
    }
  };
  
  export default editUserReducer;
  