import { DELETE_USER_FAILURE, DELETE_USER_REQUEST, DELETE_USER_SUCCESS } from "../actions/Action"

const initialState = {
    deleting: false,
    deleted: false,
    error: null,
    id: null
  }
  
  const deleteUserReducer = (state = initialState, action) => {
    switch (action.type) {
      case DELETE_USER_REQUEST:
        return {
          ...state,
          deleting: true,
          deleted: false,
          error: null,
          id: null
        }
      case DELETE_USER_SUCCESS:
        return {
          ...state,
          deleting: false,
          deleted: true,
          error: null,
          id: action.payload.id
        }
      case DELETE_USER_FAILURE:
        return {
          ...state,
          deleting: false,
          deleted: false,
          error: action.payload.error,
          id: null
        }
      default:
        return state
    }
  }
  
  export default deleteUserReducer;
  