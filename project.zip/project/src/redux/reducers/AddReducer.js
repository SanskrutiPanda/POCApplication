import { ADD_USER_REQUEST, ADD_USER_SUCCESS, ADD_USER_FAILURE } from "../actions/Action";

const initialState = {
  added: false,
  loading: false,
  error: null,
  id: null,
};

const addReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_USER_REQUEST:
      return {
        ...state,
        added: false,
        loading: true,
        error: null,
        id: null,
      };
    case ADD_USER_SUCCESS:
      return {
        ...state,
        added: true,
        loading: false,
        error: null,
        id: action.payload.id,
      };
    case ADD_USER_FAILURE:
      return {
        ...state,
        added: false,
        loading: false,
        error: action.payload.error,
        id: null,
      };
    default:
      return state;
  }
};

export default addReducer;