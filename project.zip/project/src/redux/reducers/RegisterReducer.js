import { REGISTER_REQUEST,REGISTER_SUCCESS,REGISTER_FAILURE } from "../actions/Action";
const initialState = {
  loading: false,
  registered:false,
  error: null,
  token: null,
  id: null,
};

const registerReducer = (state = initialState, action) => {
  switch (action.type) {
    case REGISTER_REQUEST:
      return {
        ...state,
        loading: true,
        registered: false,
        error: null,
        token: null,
      };
    case REGISTER_SUCCESS:
      return {
        ...state,
        loading: false,
        registered: true,
        error: null,
        token: action.payload.token,
        id: action.payload,
      };
    case REGISTER_FAILURE:
      return {
        ...state,
        loading: false,
        registered: false,
        error: action.error,
        token: null,
        id: null,
      };
    default:
      return state;
  }
};

export default registerReducer;
