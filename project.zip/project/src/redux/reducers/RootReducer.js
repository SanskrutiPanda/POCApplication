import { combineReducers } from 'redux';
import registerReducer from './RegisterReducer';
import dashReducer from './DashReducer';
import loginReducer from './LoginReducer';
import addReducer from './AddReducer';
import deleteUserReducer from './DeleteReducer';
import editUserReducer from './EditReducer';

const rootReducer = combineReducers({
    registration: registerReducer,
    login: loginReducer,
    dashboard: dashReducer,
    addReducer:addReducer,
    deleteUser: deleteUserReducer,
    editUser: editUserReducer,
});

export default rootReducer;