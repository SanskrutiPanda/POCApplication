import { LOGIN_SUCCESS, LOGIN_REQUEST, LOGIN_FAILURE } from "../actions/Action";

const initialState = {
    loggedIn: false,
    loading: false,
    error: null,
    token: null,
};

const loginReducer = (state = initialState, action) => {
    switch (action.type) {
        case LOGIN_REQUEST:
            return {
                ...state,
                loading: true,
                error: null,
            };
        case LOGIN_SUCCESS:
            return {
                ...state,
                loading: false,
                error: null,
                loggedIn: true,
                token: action.payload.token,
            };
        case LOGIN_FAILURE:
            return {
                ...state,
                loading: false,
                error: action.payload.error,
                loggedIn: false,
                token: null
            };
        default:
            return state;
    }
};

export default loginReducer;
