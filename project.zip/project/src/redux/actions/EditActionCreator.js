import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";
import { editUserRequest, editUserSuccess, editUserFailure } from './EditAction';

export const editUser = (id, name, job) => {
  return dispatch => {
    dispatch(editUserRequest());
    axios.put(`https://reqres.in/api/users/${id}`, {
      name,
      job
    }).then(response => {
      dispatch(editUserSuccess(response.data));
      toast.success("Edited successfully!", {
        autoClose: 1000,
      });
    }).catch(error => {
      dispatch(editUserFailure(error.message, {
        autoClose: 1000,
      }));
      toast.error("Edit failed!")
    });
  };
};