import { ADD_USER_REQUEST, ADD_USER_SUCCESS, ADD_USER_FAILURE } from "./Action";

export const addUserRequest = (name, job) => {
  return {
    type: ADD_USER_REQUEST,
    payload: {
      name,
      job,
    },
  };
};

export const addSuccess = (id) => {
  return {
    type: ADD_USER_SUCCESS,
    payload: {
      id,
    },
  };
};

export const addFailure = (error) => {
  return {
    type: ADD_USER_FAILURE,
    payload: {
      error,
    },
  };
};