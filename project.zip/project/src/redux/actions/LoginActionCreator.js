import axios from "axios";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { loginFailure, loginSuccess, loginUserRequest } from "./LoginAction";

export const loginRequest = (email, password, isAdmin) => {

    return dispatch => {
        dispatch(loginUserRequest(email, password, isAdmin))
        // axios.post('https://reqres.in/api/login', { email, password })
        axios.post(`https://reqres.in/api/login?isAdmin=${isAdmin}`, { email, password })
            .then(response => {
                const { token } = response.data;
                dispatch(loginSuccess(token));
                localStorage.setItem("loginToken", token);
                toast.success("Login successfull!", {
                    autoClose: 1000,
                });
            })
            .catch(error => {
                dispatch(loginFailure(error.message));
                toast.error("Login failed!", {
                    autoClose: 1000,
                });
            });
    };
};