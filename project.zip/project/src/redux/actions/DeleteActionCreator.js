import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";
import { deleteUserRequest, deleteUserSuccess, deleteUserFailure } from './DeleteAction';

export const deleteUser = (id) => {
    return (dispatch) => {
      dispatch(deleteUserRequest());
      axios.delete(`https://reqres.in/api/users/${id}`)
        .then(response => {
          const { id } = response.data;
          dispatch(deleteUserSuccess(id));
          toast.success("Deleted successfully!", {
            autoClose: 1000,
          });
        })
        .catch(error => {
          const errorMsg = error.message;
          dispatch(deleteUserFailure(errorMsg));
          toast.error("Deletion failed!", {
            autoClose: 1000,
          });
        });
    }
  }