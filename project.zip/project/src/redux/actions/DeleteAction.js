import { DELETE_USER_REQUEST, DELETE_USER_SUCCESS, DELETE_USER_FAILURE } from "./Action";

export const deleteUserRequest = () => {
    return {
      type: DELETE_USER_REQUEST
    }
  }
  
  export const deleteUserSuccess = (id) => {
    return {
      type: DELETE_USER_SUCCESS,
      payload: {
        id
      }
    }
  }
  
  export const deleteUserFailure = (error) => {
    return {
      type: DELETE_USER_FAILURE,
      payload: {
        error
      }
    }
  }