import { REGISTER_REQUEST,REGISTER_SUCCESS,REGISTER_FAILURE } from "./Action";

export const registerUserRequest = (email, password) => ({
  type: REGISTER_REQUEST,
  payload: { email, password },
});

export const registerSuccess = (id,token) => ({
  type: REGISTER_SUCCESS,
  payload: { id, token },
});

export const registerFailure = (error) => ({
  type: REGISTER_FAILURE,
  payload: { error },
});
