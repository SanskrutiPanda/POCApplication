import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";
import { addFailure, addSuccess, addUserRequest } from "./AddAction";

export const addUser = (name, job) => {
  return (dispatch) => {
    dispatch(addUserRequest(name, job));
    axios
      .post("https://reqres.in/api/users", { name, job })
      .then((response) => {
        const { name, job, id, createdAt } = response.data;
        dispatch(addSuccess(id));
        toast.success("Added successfully!", {
          autoClose: 1000,
        });
      })
      .catch((error) => {
        dispatch(addFailure(error.message));
        toast.error("Addition failed!", {
          autoClose: 1000,
        });
      });
  };
};