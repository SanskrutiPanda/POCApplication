import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { registerFailure, registerSuccess, registerUserRequest } from './RegisterAction';

export const registerRequest = (email, password) => {
  return (dispatch) => {
    dispatch(registerUserRequest(email, password));
    axios.post('https://reqres.in/api/register', {
      email,
      password,
    })
      .then((response) => {
        const { id, token } = response.data;
        dispatch(registerSuccess(id, token));
        localStorage.setItem('registrationToken', token);
        toast.success("Registration successfull!", {
          autoClose: 1000,
        });
      })
      .catch((error) => {
        dispatch(registerFailure(error.message));
        toast.error("Registration failed!", {
          autoClose: 1000,
        });
      });
  };
};
