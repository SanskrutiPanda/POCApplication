import axios from 'axios';
import { FETCH_USERS_SUCCESS, FETCH_USERS_FAILURE } from './Action';
import { fetchUsersRequest } from './DashAction';

export const fetchUsers = (page) => {
  return (dispatch) => {
    dispatch(fetchUsersRequest());
    axios.get(`https://reqres.in/api/users?page=${page}`)
      .then(response => {
        const users = response.data.data;
        const tpage = response.data.total_pages;
        dispatch({
          type: FETCH_USERS_SUCCESS,
          payload: users,
          tpage: tpage
        });
      })
      .catch(error => {
        const errorMsg = error.message;
        dispatch({
          type: FETCH_USERS_FAILURE,
          payload: errorMsg
        });
      });
  };
};
