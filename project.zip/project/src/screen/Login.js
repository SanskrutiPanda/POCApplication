import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import '../style/LoginStyle.css';
import { useSelector, useDispatch } from 'react-redux';
import { loginRequest } from "../redux/actions/LoginActionCreator";
import LoadingSpinner from "../utils/LoadingSpinner";
import 'react-toastify/dist/ReactToastify.css';

import { Button, Grid, TextField, InputAdornment, FormControlLabel, Checkbox } from '@mui/material';
import { Email, Lock, Visibility, VisibilityOff, AccountCircle } from '@mui/icons-material';


function Login() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false)

  const dispatch = useDispatch();
  const isLogIn = useSelector((state) => state.login.loggedIn);
  const loading = useSelector((state) => state.login.loading);
  const registrationToken = localStorage.getItem("registrationToken")

  const navigate = useNavigate();

  const buttonStyle = {
    borderRadius: '4px',
    padding: '7px 30px',
    fontWeight: 'bold',
    textTransform: 'capitalize',
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.25)',
    '&:hover': {
      backgroundColor: '#00b1ba',
    },
    marginTop: '1rem',
    marginLeft: '1rem',
  };

  const smallScreenButtonStyle = {
    ...buttonStyle,
    marginTop: '1rem',
    marginLeft: '0',
  };

  useEffect(() => {
    if (isLogIn || registrationToken) {
      navigate("/dashboard")
    } else {
      navigate("/")
    }
  }, [isLogIn])

  const validateEmail = (email) => {
    const regex = /\S+@\S+\.\S+/;
    return regex.test(email);
  };

  //To handle the login request
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      setEmailError("Please enter a valid email address");
    } else {
      setEmailError("");
      dispatch(loginRequest(email, password,isAdmin));
    }
  }

  const clearInput = () => {
    setEmail("");
    setPassword("");
    setError("");
    setEmailError("");
  }

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleCheckChange = (event) => {
    setIsAdmin(event.target.checked)
  }

  // JSX code for login form
  const renderForm = (
    <Grid container>
      <Grid item xs={12}>
        <TextField
          name="email"
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          size="small"
          error={emailError ? true : false}
          helperText={emailError && emailError}
          sx={{ margin: '0.7rem 0.5rem' }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Email />
              </InputAdornment>
            ),
          }}
        />
      </Grid>
      <Grid item xs={12}>
        <TextField
          name="password"
          label="Password"
          type={showPassword ? 'email' : 'password'}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          fullWidth
          size="small"
          sx={{ margin: '0.7rem 0.5rem' }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Lock />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                {password && (
                  <Button onClick={handleTogglePasswordVisibility}>
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </Button>
                )}
              </InputAdornment>
            ),
          }}
        />
      </Grid>
      <Grid item xs={12} sx={{
        display: "flex",
        alignItems: "flex-start",
        marginLeft: "8px"
      }}>
        <FormControlLabel
          control={<Checkbox checked={isAdmin} onChange={handleCheckChange} name="checkedA" />}
          label="Loggin in as an ADMIN"
        />
      </Grid>
      <Grid item xs={12}>
        <Button
          variant="contained"
          color="primary"
          sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
          disabled={email.trim() === '' || password.trim() === ''}
          onClick={handleSubmit}
          className="screenButton" >Login</Button>
        <Button
          variant="contained"
          color="primary"
          sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
          onClick={clearInput} >Reset</Button>
      </Grid>
      <Grid item xs={12}>
        <label style={{ marginTop: '2rem', display: 'block' }}>
          New Here? <a href="/registration">Create a new Account</a>
        </label>
      </Grid>
    </Grid>
  );

  return (
    <>
      {
        loading ? <LoadingSpinner /> : (<div className="app">
          <div className="login-form">
            <AccountCircle sx={{ fontSize: '5rem', color: '#1976D2' }} />
            <div className="title">Login</div>
            {renderForm}
          </div>
        </div>)
      }
    </>
  );
}

export default Login;