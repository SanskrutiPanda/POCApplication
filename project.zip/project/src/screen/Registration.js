
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import '../style/LoginStyle.css';
import { useDispatch, useSelector } from 'react-redux';
import { registerRequest } from "../redux/actions/RegisterActionCreator"
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import LoadingSpinner from "../utils/LoadingSpinner";

import { Button, Grid, TextField, InputAdornment } from '@mui/material';
import { Email, Lock, Visibility, VisibilityOff, AccountCircle } from '@mui/icons-material';



function Registration() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [cpassword, setCpassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [cpasswordError, setCpasswordError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showCPassword, setShowCPassword] = useState(false);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const isRegistered = useSelector((state) => state.registration.registered);
  const isLoading = useSelector((state) => (state.registration.loading));

  const buttonStyle = {
    borderRadius: '4px',
    padding: '7px 30px',
    fontWeight: 'bold',
    textTransform: 'capitalize',
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.25)',
    '&:hover': {
      backgroundColor: '#00b1ba',
    },
    marginTop: '2rem',
    marginLeft: '1rem',
  };

  const smallScreenButtonStyle = {
    ...buttonStyle,
    marginTop: '1rem',
    marginLeft: '0',
    padding: '5px 15px',
  };

  useEffect(() => {
    if (isRegistered === true) {
      navigate("/")
    }
  }, [isRegistered])

  const validateEmail = (email) => {
    const regex = /\S+@\S+\.\S+/;
    return regex.test(email);
  };

  const validatePassword = (password) => {
    const regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    return regex.test(password);
  };

  const confirmPassword = (password, cpassword) => {
    return cpassword === password;
  }

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      setEmailError("Please enter a valid email address");
    } else {
      setEmailError("");
    }

    if (!validatePassword(password)) {
      setPasswordError(
        "Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one special character and one number"
      );
    } else if (password !== cpassword) {
      setCpasswordError("Password doesn't Match! Please try again.");
    } else {
      setPasswordError("");
      setCpasswordError("");
    }

    // If both fields are valid
    if (validateEmail(email) && validatePassword(password) && confirmPassword(password, cpassword)) {
      dispatch(registerRequest(email, password));
    }
  };
  const clearInput = () => {
    setEmail("");
    setPassword("");
    setCpassword("");
    setEmailError("");
    setPasswordError("");
    setCpasswordError("");
  }

  const handleTogglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleToggleCPasswordVisibility = () => {
    setShowCPassword(!showCPassword);
  };

  // JSX code for login form
  const renderForm = (
    <Grid container>
      <Grid item xs={12}>
        <TextField
          name="email"
          label="Email"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          fullWidth
          size="small"
          error={emailError ? true : false}
          helperText={emailError && emailError}
          sx={{ margin: '0.7rem 0.5rem' }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Email />
              </InputAdornment>
            ),
          }}
        />
        <TextField
          name="password"
          label="Password"
          type={showPassword ? 'email' : 'password'}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          fullWidth
          size="small"
          error={passwordError ? true : false}
          helperText={passwordError && passwordError}
          sx={{ margin: '0.7rem 0.5rem' }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Lock />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                {password && (
                  <Button onClick={handleTogglePasswordVisibility}>
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </Button>
                )}
              </InputAdornment>
            ),
          }}
        />
        <TextField
          name="cpassword"
          label="Confirm Password"
          type={showCPassword ? 'email' : 'password'}
          value={cpassword}
          onChange={(e) => setCpassword(e.target.value)}
          fullWidth
          size="small"
          error={cpasswordError ? true : false}
          helperText={cpasswordError && cpasswordError}
          sx={{ margin: '0.7rem 0.5rem' }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Lock />
              </InputAdornment>
            ),
            endAdornment: (
              <InputAdornment position="end">
                {cpassword && (
                  <Button onClick={handleToggleCPasswordVisibility}>
                    {showCPassword ? <VisibilityOff /> : <Visibility />}
                  </Button>
                )}
              </InputAdornment>
            ),
          }}
        />
        <Button
          variant="contained"
          color="primary"
          sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
          disabled={email.trim() === '' || password.trim() === ''}
          onClick={handleSubmit}
          className="screenButton" >Register</Button>
        <Button
          variant="contained"
          color="primary"
          sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
          onClick={clearInput} >Reset</Button>
        <label style={{ marginTop: '2rem', display: 'block' }}>
          Aready have an account? <a href="/">Login here</a>
        </label>
      </Grid>
    </Grid>
  );

  return (
    <>
      {
        isLoading ? <LoadingSpinner /> : (<div className="app">
          <div className="login-form">
            <AccountCircle sx={{ fontSize: '5rem', color: '#1976D2' }} />
            <div className="title">Register User</div>
            {renderForm}
          </div>
        </div>
        )
      }
    </>
  );
}

export default Registration;