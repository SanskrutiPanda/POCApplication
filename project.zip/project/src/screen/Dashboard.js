import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchUsers } from '../redux/actions/DashActionCreator';
import { deleteUser } from '../redux/actions/DeleteActionCreator';
import { addUser } from '../redux/actions/AddActionCreator';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../style/DashboardStyle.css';
import Modal from 'react-modal';

//Imports for Navbar
import { styled, useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import CssBaseline from "@mui/material/CssBaseline";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import LoginIcon from "@mui/icons-material/Login";
import Button from '@mui/material/Button';
import AddIcon from '@mui/icons-material/Add';
import AddCircleIcon from '@mui/icons-material/AddCircle';

//Imports for Card Structure
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import { TextField } from '@mui/material';

//imports for fixed button
import { useNavigate } from 'react-router-dom';
import { editUser } from '../redux/actions/EditActionCreator';

const drawerWidth = 240;

const Dashboard = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const theme = useTheme();

  const userState = useSelector((state) => state.dashboard);
  const { loading, users, tpage, error } = userState;
  console.log(JSON.stringify(users));

  var temp = [];
  users.map((user) => temp.push(user))
  const [myArray, setMyArray] = useState([temp]);


  const addedState = useSelector((state) => state.addReducer);
  const addedId = addedState.id;

  const [open, setOpen] = useState(false)
  const [modalIsOpen, setIsOpen] = useState(false);
  const [editModalIsOpen, setEditModalIsOpen] = useState(false);
  const [deleteModalIsOpen, setDeleteModalIsOpen] = useState(false);
  const [userData, setUserData] = useState(null);
  const [crud, setCrud] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [id, setId] = useState(100);
  const [val, setVal] = useState(1);
  const [emailError, setEmailError] = useState("");
  const [fieldError, setFieldError] = useState("");
  const [deleteUserName, setDeleteUserName] = useState("");


  const [name, setName] = useState("")
  const [job, setJob] = useState("")
  const [email, setEmail] = useState("")
  const [last_name, setLname] = useState("")
  const [avatar, setAvatar] = useState("")
  const [addId, setAddId] = useState("")
  const [disable, setDisable] = useState(false)

  let subtitle;

  useEffect(() => {
    setAddId(addedId);
    dispatch(fetchUsers(1));
  }, []);

  const customStyles = {
    content: {
      top: '50%',
      left: '50%',
      right: 'auto',
      bottom: 'auto',
      marginRight: '-50%',
      transform: 'translate(-50%, -50%)',
      borderRadius: '7%',
    },
  };

  const handleDrawerOpen = () => {
    setOpen(true);
  };

  const handleDrawerClose = () => {
    setOpen(false);
  };

  const userLogOut = () => {
    localStorage.removeItem('loginToken');
    localStorage.removeItem('registrationToken')
    navigate('/');
    window.location.reload(true);
  };

  function openModal() {
    setIsOpen(true);
    setOpen(false);
  }

  const afterOpenModal = () => {
    subtitle.style.color = '#1976D2';
  }

  function closeModal() {
    setIsOpen(false);
    handleReset();
  }

  function openEditModal() {
    setEditModalIsOpen(true);
  }

  function afterOpenEditModal() {
    subtitle.style.color = '#1976D2';
  }

  function closeEditModal() {
    setEditModalIsOpen(false);
    handleReset();
  }

  function openDeleteModal() {
    setDeleteModalIsOpen(true);
  }

  function afterOpenDeleteModal() {
    subtitle.style.color = '#1976D2';
  }

  function closeDeleteModal() {
    setDeleteModalIsOpen(false);
  }

  const handleReset = () => {
    setName("");
    setEmail("");
    setJob("");
    setLname("");
    setAvatar("");
    setEmailError("");
    setFieldError("");
  }

  const handleEditReset = () => {
    setName("");
    setJob("");
    setUserData("");
    setEmailError("");
    setFieldError("");
  }

  const validateEmail = (email) => {
    const regex = /\S+@\S+\.\S+/;
    return regex.test(email);
  };

  const validateFields = (fieldState) => {
    if (fieldState.trim().length !== 0) {
      return true;
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      setEmailError("Please enter a valid email address");
    } else if (!validateFields(name) || !validateFields(job) || !validateFields(avatar) || !validateFields(last_name)) {
      setFieldError("Please enter valid field values!");
    } else {
      setEmailError("");
      dispatch(addUser(name, job));
      addData(addId);
      setIsOpen(false);
      handleReset();
    }
  }

  const addData = (addId) => {
    setCrud(true);
    let data = null;
    setId(id + 1);
    const person = {
      id: id,
      email: email,
      first_name: name,
      last_name: last_name,
      avatar: avatar
    }
    if (crud) {
      data = [...myArray]
    } else {
      data = [...temp]
    }
    data.unshift(person);
    setMyArray([
      ...data,
    ]);
  }

  const handleDeleteModal = (userId, userName) => {
    openDeleteModal();
    setDeleteId(userId);
    setDeleteUserName(userName);
  };

  const handleDeleteUser = (e) => {
    e.preventDefault();
    dispatch(deleteUser(deleteId));
    deleteUserData(deleteId);
    closeDeleteModal();
  }

  const deleteUserData = (deleteId) => {
    setCrud(true);
    let data = null;
    if (crud) {
      data = [...myArray];
    } else {
      data = [...temp]
    }
    const ind = data.findIndex((data) => data.id === deleteId);
    if (ind !== -1)
      data.splice(ind, 1);
    setMyArray([
      ...data,
    ])
  }

  const handleEditModal = (userId) => {
    let data = null;
    if (crud) {
      data = [...myArray];
    } else {
      data = [...temp];
    }
    const user = data.find((u) => u.id === userId);
    setUserData(user);
    openEditModal();
    handleReset();
  };


  const handleEditUser = (e) => {
    e.preventDefault();

    if (!validateEmail(userData.email)) {
      setEmailError("Please enter a valid email address");
    } else if (!validateFields(userData.first_name) || !validateFields(userData.last_name) || !validateFields(job) || !validateFields(userData.avatar)) {
      setDisable(true);
      setFieldError("Please enter valid field values!");
    } else {
      setEmailError("");
      dispatch(editUser(userData.id, name, job));
      setEditModalIsOpen(false);
      editUserData(userData.id, userData);
      handleReset();
    }
  }

  const editUserData = (editId, editData) => {
    setCrud(true);
    setVal(val + 1);
    const ind = temp.findIndex((data) => data.id === editId);
    if (ind !== -1) {
      temp.splice(ind, 1, editData);
      setMyArray([
        ...temp,
      ])
    } else {
      setMyArray([
        editData,
        ...temp,
      ])
    }
  }

  const buttonStyle = {
    borderRadius: '4px',
    padding: '5px 25px',
    fontWeight: 'bold',
    textTransform: 'capitalize',
    boxShadow: '0px 2px 4px rgba(0, 0, 0, 0.25)',
    '&:hover': {
      backgroundColor: '#00b1ba',
    },
    marginTop: '1rem',
    marginLeft: '0.5rem',
  };

  const smallScreenButtonStyle = {
    ...buttonStyle,
    marginTop: '0.5rem',
    marginLeft: '0',
  };

  const AppBar = styled(MuiAppBar, {
    shouldForwardProp: (prop) => prop !== "open"
  })(({ theme, open }) => ({
    transition: theme.transitions.create(["margin", "width"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    ...(open && {
      width: `calc(100% - ${drawerWidth}px)`,
      marginLeft: `${drawerWidth}px`,
      transition: theme.transitions.create(["margin", "width"], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen
      })
    })
  }));

  const DrawerHeader = styled("div")(({ theme }) => ({
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(0, 1),
    ...theme.mixins.toolbar,
    justifyContent: "flex-end"
  }));

  const Main = styled("main", { shouldForwardProp: (prop) => prop !== "open" })(
    ({ theme, open }) => ({
      flexGrow: 1,
      padding: theme.spacing(3),
      transition: theme.transitions.create("margin", {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen
      }),
      marginLeft: `-${drawerWidth}px`,
      ...(open && {
        transition: theme.transitions.create("margin", {
          easing: theme.transitions.easing.easeOut,
          duration: theme.transitions.duration.enteringScreen
        }),
        marginLeft: 0
      })
    })
  );

  return (
    <div className='dashboard'>
      <Box sx={{ display: "flex" }}>
        <CssBaseline />
        <AppBar position="fixed" open={open} >
          <Toolbar sx={{
            justifyContent: "space-between"
          }}>
            <IconButton
              color="inherit"
              aria-label="open drawer"
              onClick={handleDrawerOpen}
              edge="start"
              sx={{ mr: 2, ...(open && { display: "none"}) }}>
              <MenuIcon />
            </IconButton>
            <Typography sx={{ display: { xs: "none", sm: "block" } }} variant="h6" noWrap component="div">
              <span style={{ fontWeight: "bold" }}>Dashboard</span>
            </Typography>
            <Button
              sx={{
                backgroundColor: "#1976D2",
                textTransform: "capitalize",
                "&:hover": {
                  backgroundColor: "#3F51B5",
                },
                visibility: { xs: "hidden", sm: "visible", md:"visible" },
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end",
              }}
              variant="outlined"
              size="large"
              color="inherit"
              onClick={openModal}
            >
              <AddCircleIcon sx={{ marginRight: "0.5rem" }} />
              <span style={{ fontWeight: "bold" }}>Add</span>
            </Button>

          </Toolbar>
        </AppBar>
        <Drawer
          sx={{
            width: drawerWidth,
            flexShrink: 0,
            "& .MuiDrawer-paper": {
              width: drawerWidth,
              boxSizing: "border-box",
            }
          }}
          variant="persistent"
          anchor="left"
          open={open}
        >
          <DrawerHeader>
            <IconButton onClick={handleDrawerClose}>
              {theme.direction === "ltr" ? (
                <ChevronLeftIcon />
              ) : (
                <ChevronRightIcon />
              )}
            </IconButton>
          </DrawerHeader>
          <Divider />
          <List>
            <ListItem sx={{ display: { xs: "flex", sm: "none" }, backgroundColor: "#d6d5d2" }} >
              <ListItemText primary={"Dashboard"} />
            </ListItem>
            <ListItem button onClick={openModal} sx={{ display: { xs: "flex", sm: "none" } }} >
              <ListItemIcon>
                <AddIcon />
              </ListItemIcon>
              <ListItemText primary={"Add Data"} />
            </ListItem>
            <ListItem button onClick={userLogOut} >
              <ListItemIcon>
                <LoginIcon />
              </ListItemIcon>
              <ListItemText primary={"Logout"} />
            </ListItem>
          </List>
        </Drawer>
        <Main open={open}>
          <DrawerHeader />
        </Main>
      </Box>

      <div className="user-list">
        {!crud ?
          users.map((user) => (
            <Card key={user.id} className='myCard'>
              <CardMedia
                className='myCardMedia'
                image={user.avatar}
                title={user.first_name}
              />
              <Divider sx={{ mt: 2 }} />
              <CardContent>
                <Typography gutterBottom variant="h6" component="div"
                  className='myTypography'>
                  {`${user.first_name} ${user.last_name}`}
                </Typography>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  className='myTypographyEmail'
                  title={user.email}>
                  {user.email}
                </Typography>

              </CardContent>
              <CardActions sx={{ display: "flex", justifyContent: "center" }}>
                <Button variant="contained" size="small" onClick={() => handleEditModal(user.id)} ><EditIcon /></Button>
                <Button variant="contained" size="small" onClick={() => handleDeleteModal(user.id, user.first_name)}><DeleteIcon /></Button>
              </CardActions>
            </Card>
          )) :
          myArray.map((user) => (
            <Card key={user.id} className='myCard'>
              <CardMedia
                className='myCardMedia'
                image={user.avatar}
                title={user.first_name}
              />
              <Divider sx={{ mt: 2 }} />
              <CardContent>
                <Typography gutterBottom variant="h6" component="div"
                  className='myTypography'>
                  {`${user.first_name} ${user.last_name}`}
                </Typography>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  className='myTypographyEmail'
                  title={user.email}
                >
                  {user.email}
                </Typography>

              </CardContent>
              <CardActions sx={{ display: "flex", justifyContent: "center" }}>
                <Button variant="contained" size="small" onClick={() => handleEditModal(user.id)} ><EditIcon /></Button>
                <Button variant="contained" size="small" onClick={() => handleDeleteModal(user.id, user.first_name)}><DeleteIcon /></Button>
              </CardActions>
            </Card>
          ))}
      </div>

      <Modal
        ariaHideApp={false}
        isOpen={editModalIsOpen}
        onAfterOpen={afterOpenEditModal}
        onRequestClose={closeEditModal}
        style={customStyles}
        contentLabel="Example Modal"
      >
        <h2 ref={(_subtitle) => (subtitle = _subtitle)}>Edit Data of User</h2>
        <button id='popup__close-btn' onClick={closeEditModal}>X</button>
        <form>
          <div className="input-container">
            <TextField
              name="name"
              label="First Name"
              type="text"
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              value={userData ? userData.first_name : ""}
              onChange={(e) => {
                setUserData({ ...userData, first_name: e.target.value })
                setName(e.target.value)
              }}
              size="small"
            />
            <TextField
              name="lastName"
              label="Last Name"
              type="text"
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              value={userData ? userData.last_name : ""}
              onChange={(e) => {
                setUserData({ ...userData, last_name: e.target.value })
              }}
              size="small"
            />
            <TextField
              name="job"
              label="Job"
              type="text"
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              value={job}
              onChange={(e) => setJob(e.target.value)}
              size="small"
            />
            <TextField
              name="email"
              label="Email"
              type="text"
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              value={userData ? userData.email : ""}
              onChange={(e) => {
                setUserData({ ...userData, email: e.target.value })
                setEmail(e.target.value)
              }}
              error={emailError ? true : false}
              helperText={emailError && emailError}
              size="small"
            />
            <TextField
              name="avatar"
              label="Avatar"
              type="text"
              id="standard-basic"
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              value={userData ? userData.avatar : ""}
              onChange={(e) => setUserData({ ...userData, avatar: e.target.value })}
              size="small"
            />

          </div>
          <div className="style.button-container">
            <Button
              variant="contained"
              color="primary"
              sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
              onClick={handleEditUser}
              disabled={
                !userData ||
                userData.first_name.trim() === '' ||
                userData.last_name.trim() === '' ||
                job.trim() === '' ||
                userData.email.trim() === '' ||
                userData.avatar.trim() === ''
              }
              className="screenButton" >Edit</Button>
            <Button
              variant="contained"
              color="primary"
              sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
              onClick={handleEditReset} >Reset</Button>
          </div>
          <ToastContainer />
        </form>
      </Modal>

      <Modal
        ariaHideApp={false}
        isOpen={modalIsOpen}
        onAfterOpen={afterOpenModal}
        onRequestClose={closeModal}
        style={customStyles}
        contentLabel="Example Modal"
      >
        <h2 ref={(_subtitle) => (subtitle = _subtitle)}>Add a new User to Dashboard</h2>
        <button id='popup__close-btn' onClick={closeModal}>X</button>
        <form>
          <div className="input-container">
            <TextField
              name="name"
              label="First Name"
              type="text"
              value={name}
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              onChange={(e) => setName(e.target.value)}
              size="small"
            />
            <TextField
              name="lastName"
              label="Last Name"
              type="text"
              value={last_name}
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              onChange={(e) => setLname(e.target.value)}
              size="small"
            />
            <TextField
              name="job"
              label="Job"
              type="text"
              value={job}
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              onChange={(e) => setJob(e.target.value)}
              size="small"
            />
            <TextField
              name="email"
              label="Email"
              type="text"
              value={email}
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              onChange={(e) => setEmail(e.target.value)}
              error={emailError ? true : false}
              helperText={emailError && emailError}
              size="small"
            />
            <TextField
              name="avatar"
              label="Avatar"
              type="text"
              value={avatar}
              id="standard-basic"
              variant="standard"
              sx={{ margin: '0.4rem 0.2rem' }}
              onChange={(e) => setAvatar(e.target.value)}
              size="small"
            />
          </div>
          <div className="style.button-container">
            <Button
              variant="contained"
              color="primary"
              sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
              disabled={name.trim() === '' || last_name.trim() === '' || job.trim() === '' || email.trim() === '' || avatar.trim() === ''}
              onClick={handleSubmit}
              className="screenButton" >Add</Button>
            <Button
              variant="contained"
              color="primary"
              sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
              onClick={handleReset} >Reset</Button>
          </div>
          <ToastContainer />
        </form>
      </Modal>

      <Modal
        ariaHideApp={false}
        isOpen={deleteModalIsOpen}
        onAfterOpen={afterOpenDeleteModal}
        onRequestClose={closeDeleteModal}
        style={customStyles}
        contentLabel="Example Modal"
      >
        <h4 ref={(_subtitle) => (subtitle = _subtitle)}>Are you sure you want to delete <span className='deleteUserName'>{deleteUserName}</span>?</h4>
        <form>
          <div className="style.button-container">
            <Button
              variant="contained"
              color="primary"
              sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
              onClick={handleDeleteUser}
              className="screenButton" >Yes</Button>
            <Button
              variant="contained"
              color="primary"
              sx={{ ...buttonStyle, '@media (max-width: 600px)': smallScreenButtonStyle }}
              onClick={closeDeleteModal} >No</Button>
          </div>
          <ToastContainer />
        </form>
      </Modal>

      <ToastContainer />

    </div>
  );
};

export default Dashboard;