import React from 'react'

const PocStatus = () => {
  return (
    <div>PocStatus</div>
  )
}

export default PocStatus