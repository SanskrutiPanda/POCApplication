import { Grid, Typography, Box, Button } from '@mui/material'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

const UserDashboard = () => {

    const navigate = useNavigate()

    const options = [
        { "submit-poc": "Submit a POC form" },
        { "poc-status": "Get POC status" },
        { "renew-poc": "Renew your POC form" },
        { "download-solution": "Download your POC solution" }
    ]

    const [selectedRoute, setSelectedRoute] = useState("")

    const handleOptionClick = (key) => {
        setSelectedRoute(key)
    }

    const handleProceed = () => {
        if (selectedRoute) {
            navigate(`${selectedRoute}`)
        } else {
            toast.error("Please select an option")
        }
    }

    return (
        <Box
            sx={{
                padding: "30px"
            }}
        >
            <Grid container>
                {
                    options.map((item, index) => (
                        <Grid item xs={12} md={6} lg={6} key={index}>
                            {
                                Object.entries(item).map(([key, value]) => (
                                    <Box
                                        sx={{
                                            border: key === selectedRoute ? "2px solid #1976d2" : "2px solid #bfbfbf",
                                            height: "200px",
                                            margin: "30px",
                                            borderRadius: "20px",
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            background: key === selectedRoute ? "#1976d2" : "#fff",
                                            cursor: "pointer"
                                        }}
                                        onClick={() => handleOptionClick(key)}
                                    >
                                        <Typography
                                            key={key}
                                            fontSize="1rem"
                                            color={key === selectedRoute ? "#fff" : "#bfbfbf"}
                                            fontWeight="bold"
                                        >
                                            {value}
                                        </Typography>
                                    </Box>
                                ))
                            }
                        </Grid>
                    ))
                }
            </Grid>
            <Box
                sx={{
                    marginTop: "30px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                }}
            >
                <Button
                    variant='contained'
                    onClick={handleProceed}
                    fontWeight="600"
                >
                    Proceed
                </Button>
            </Box>
        </Box>
    )
}

export default UserDashboard