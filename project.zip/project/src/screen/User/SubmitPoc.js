import React from 'react'

const SubmitPoc = () => {
  return (
    <div>SubmitPoc</div>
  )
}

export default SubmitPoc