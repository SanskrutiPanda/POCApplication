import React from 'react'

const RenewPoc = () => {
  return (
    <div>RenewPoc</div>
  )
}

export default RenewPoc