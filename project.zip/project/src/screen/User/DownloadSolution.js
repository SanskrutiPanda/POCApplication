import React from 'react'

const DownloadSolution = () => {
  return (
    <div>DownloadSolution</div>
  )
}

export default DownloadSolution