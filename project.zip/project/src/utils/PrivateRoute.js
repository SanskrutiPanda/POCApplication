import React from 'react';
import Login from '../screen/Login';

export default function PrivateRoute({ isAuthenticated, component: Component }) {
  return (
    isAuthenticated ? <Component /> : <Login />
  )
}